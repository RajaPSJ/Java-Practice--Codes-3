package fighting;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author rajap
 */
public class Fighting {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random generator = new Random();
        
        System.out.print("Your Attack Points:");
        int yourattack = generator.nextInt(6)+5;
        System.out.println(yourattack);
        System.out.print("Your Defence Points:");
        int yourdefence = generator.nextInt(6)+10;
        System.out.println(yourdefence);
        System.out.print("Your Damage");
        int yourdamage = generator.nextInt(3)+2;
        System.out.println(yourdamage);
        System.out.print("Your Life Points: ");
        int yourlife = generator.nextInt(20)+25;
        System.out.println(yourlife);
        
        for (int i = 0; i < 3; i++) {
            String monsterName;
            int num = generator.nextInt(5);
            switch (num) {
                case 0: monsterName = "Black Daemon"; break;
                case 1: monsterName = "The Rabbit"; break;
                case 2: monsterName = "Silver Dragon"; break;
                case 3: monsterName = "Mountain Troll"; break;
                case 4: monsterName = "Alien"; break;
                default: monsterName = "N/A"; break;
            }
            System.out.print("Attack Points of "+monsterName+":");
            int monsterattack = generator.nextInt(8)+1;
            System.out.println(monsterattack);
            System.out.print("Deffence Points of "+monsterName+":");
            int monsterdeffence =generator.nextInt(10)+3;
            System.out.println(monsterdeffence);
            System.out.print("Damage of "+monsterName+":");
            int monsterdamage = generator.nextInt(3)+1;
            System.out.println(monsterdamage);
            System.out.print("Life point of "+monsterName+":");
            int monsterlife = generator.nextInt(20)+15;
            System.out.println(monsterlife);



            //sc.nextLine();
            boolean runaway = false;


            do{
                boolean attacker = generator.nextBoolean();
                if (attacker){  
                    System.out.println("You attack");
                    int dice = generator.nextInt(6)+1+generator.nextInt(6)+1;
                    int attackvalue = yourattack +dice;
                    System.out.println("Rolled Values:"+dice);
                    System.out.println("Your Attack Value :"+attackvalue);
                    if (attackvalue>monsterdeffence)
                    {
                        System.out.println("Your Attack was Successfull.");
                        monsterlife = monsterlife - yourdamage;
                        System.out.println(monsterName+"'s remaining Life Points:"+monsterlife);
                    }
                    else
                    {
                        System.out.println("Your Attack was not Successfull.");
                    }

                }

                else
                {
                    System.out.println(monsterName+"'s Attack was not Sucessfull.");
                }   
                System.out.println("Press ENTER to continue.(or type in 'run' to runaway)");
                String command = sc.nextLine();
                switch (command) {
                    case "run": 
                        System.out.println("You ranaway. You coward! -4 Life points!");
                        yourlife -= 4;
                        runaway = true;
                        break;
                    default:    
                }
          } while (yourlife > 0 && monsterlife > 0 && !runaway);
            if (yourlife <= 0) {
                System.out.println("You are dead. R.I.P :-");
                break;
            }
            if (monsterlife <= 0) {
                System.out.println("You won. The "+monsterName+" is dead.");
            }
    }
    }
    
    
}